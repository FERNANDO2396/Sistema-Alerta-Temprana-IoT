#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// Configuración de pines
#define DHTPIN 15
#define DHTTYPE DHT22
#define LED_ROJO 26
#define LED_VERDE 25
#define VENTILADOR 14
#define BUZZER 27

// Inicializar sensor DHT
DHT dht(DHTPIN, DHTTYPE);

// Configuración WiFi (usa tus credenciales)
const char* ssid = "Wokwi-GUEST";      // Para Wokwi
const char* password = "";             // Para Wokwi

// Configuración Mosquitto público gratuito
const char* mqtt_server = "test.mosquitto.org";
const int mqtt_port = 1883;            // Puerto no encriptado

// Topics MQTT (personalízalos)
const char* topic_paro_F = "FER/paro";
const char* topic_temp_F = "FER_temp";
const char* topic_hum_F = "FERhum";
const char* topic_status_F = "FER/status";

WiFiClient espClient;
PubSubClient client(espClient);

// Variables del sistema
bool system_active = true;
unsigned long lastPublishTime = 0;
const long publishInterval = 2000; // 2 segundos

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Conectando a ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi conectado");
  Serial.println("Dirección IP: ");
  Serial.println(WiFi.localIP());
}

void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Mensaje recibido [");
  Serial.print(topic);
  Serial.print("] ");
  
  String message;
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  Serial.println(message);

  if (String(topic) == topic_paro_F) {
    if (message.equals("OFF")) {
      system_active = false;
      digitalWrite(VENTILADOR, LOW);
      digitalWrite(BUZZER, LOW);
      digitalWrite(LED_ROJO, LOW);
      digitalWrite(LED_VERDE, LOW);
      Serial.println("Sistema detenido por MQTT");
    } else if (message.equals("ON")) {
      system_active = true;
      Serial.println("Sistema reactivado por MQTT");
    }
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Intentando conexión MQTT...");
    
    // Crear un Client ID único
    String clientId = "ESP32_FERNANDO";
    clientId += String(random(0xffff), HEX);
    
    // Intentar conectar (sin usuario/contraseña)
    if (client.connect(clientId.c_str())) {
      Serial.println("Conectado al broker Mosquitto público");
      
      // Publicar mensaje de conexión
      client.publish(topic_status_F, "Conectado");
      
      // Suscribirse a topics
      client.subscribe(topic_paro_F);
      Serial.println("Suscrito a topic_paro");
    } else {
      Serial.print("Error, rc=");
      Serial.print(client.state());
      Serial.println(" Intentando de nuevo en 5 segundos...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  // Inicializar sensor DHT
  dht.begin();
  
  // Configurar pines
  pinMode(LED_ROJO, OUTPUT);
  pinMode(LED_VERDE, OUTPUT);
  pinMode(VENTILADOR, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  
  // Iniciar WiFi
  setup_wifi();
  
  // Configurar MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  unsigned long currentTime = millis();
  if (currentTime - lastPublishTime >= publishInterval) {
    lastPublishTime = currentTime;
    
    if (system_active) {
      float temp = dht.readTemperature();
      float hum = dht.readHumidity();

      if (!isnan(temp) && !isnan(hum)) {
        // Publicar datos (sin retain para evitar saturar el broker público)
        client.publish(topic_temp_F, String(temp).c_str());
        client.publish(topic_hum_F, String(hum).c_str());
        
        Serial.print("Publicado - Temp: ");
        Serial.print(temp);
        Serial.print("°C, Hum: ");
        Serial.print(hum);
        Serial.println("%");

        // Control de actuadores
        if (temp > 30) {
          digitalWrite(LED_ROJO, HIGH);
          digitalWrite(VENTILADOR, HIGH);
          digitalWrite(BUZZER, HIGH);
        } else {
          digitalWrite(LED_ROJO, LOW);
          digitalWrite(VENTILADOR, LOW);
          digitalWrite(BUZZER, LOW);
        }

        if (hum < 40) {
          digitalWrite(LED_VERDE, HIGH);
        } else {
          digitalWrite(LED_VERDE, LOW);
        }
      } else {
        Serial.println("Error al leer el sensor DHT22");
      }
    }
  }
}